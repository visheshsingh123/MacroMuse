NutriGlance Android startup test — 1.0.1.0 (version code 2)

Install NutriGlance-startup-test.apk after the website deployment completes.
Test cold starts and repeated launches, then verify sign-in and reminders.
The APK waits briefly for Chrome website verification while holding its splash.
Chrome's own notices remain browser-controlled. This is a candidate mitigation,
not a guarantee of a toolbar-free launch on every device.

This package includes editable Android source and signed APK/AAB builds.
Private signing keys and passwords are excluded. Keep your PWABuilder keystore
and reuse it for future builds. This candidate uses the key from your latest
source upload. A differently signed older installation cannot be updated in place;
its original key is needed to produce an update-compatible build.

This approved build is now the main APK download. Website association:
https://nutriglance.vercel.app/.well-known/assetlinks.json
